package tutormodel;

/**
 * The reason that the answer is incorrect.
 * Depends on the specific domain.
 * @author micky
 * Copyright ATIBO 2013-2015
 *
 */
public interface Reason {
	public void findReason();

}
