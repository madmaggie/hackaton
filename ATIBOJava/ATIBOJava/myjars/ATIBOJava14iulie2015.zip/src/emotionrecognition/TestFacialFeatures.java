package emotionrecognition;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class TestFacialFeatures extends JFrame {
	
	public TestFacialFeatures() {
		
		//System.out.println(System.getProperty("java.library.path"));
		System.out.println(System.getProperty("jna.library.path"));
		//System.out.println(System.getProperty("file.separator"));
		//System.out.println(System.getProperty("os.arch"));
		setLocation(0, 0);
		setTitle("ATIBO Emotion Recognition");
		setBackground(Color.lightGray);
		setIconImage(new ImageIcon("img/atibo.jpg").getImage());
		setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		
		addWindowListener(new WindowAdapter() {
        
			public void windowClosing(WindowEvent e) {                  
	           int returnValue = JOptionPane.showConfirmDialog(TestFacialFeatures.this,
	                     "Esti sigur ca vrei sa inchizi ATIBO?", "Confirm",
	                     JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
	           if (returnValue == JOptionPane.NO_OPTION) {
	                return;
	           }
	           else {
                   System.exit(0);
	           }
	        }
		});

		pack();
		setVisible(true);
	}

	public static void main(String[] args) {
		DetectFacialFeatures dff = new DetectFacialFeatures();
		dff.FacialFeatures(new TestFacialFeatures());
	}
}
