package emotionrecognition;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Platform;
import com.sun.jna.Pointer;

public class TestMatlabDll {
	
	//static {
		//System.load("/media/micky/WORK/eclipseluna/ATIBOJava/lib/libhello.so");
		//System.out.println(System.getProperty("java.library.path"));
		//System.loadLibrary("libhello.so");
	//}
	
	/*public interface simpleDLL extends Library {
        simpleDLL INSTANCE = (simpleDLL) Native.loadLibrary("hello", simpleDLL.class);
        // it's possible to check the platform on which program runs
        // for example purposes we assume that there's a linux port of the library (it's not attached to the downloadable project)
        // simpleDLL INSTANCE = (simpleDLL) Native.loadLibrary(
         //       (Platform.isWindows() ? "simpleDLL" : "simpleDLLLinuxPort"), simpleDLL.class);
        
        // alte functii din dll
        //byte giveVoidPtrGetChar(Pointer param); // char giveVoidPtrGetChar(void* param);
        //int giveVoidPtrGetInt(Pointer param);   //int giveVoidPtrGetInt(void* param);
        //int giveIntGetInt(int a);               // int giveIntGetInt(int a);
        double hello();                      // void simpleCall();
    }*/
	
	public interface dtwDLL extends Library {
        dtwDLL INSTANCE = (dtwDLL) Native.loadLibrary("dtw", dtwDLL.class);
        // it's possible to check the platform on which program runs
        // for example purposes we assume that there's a linux port of the library (it's not attached to the downloadable project)
        // simpleDLL INSTANCE = (simpleDLL) Native.loadLibrary(
         //       (Platform.isWindows() ? "simpleDLL" : "simpleDLLLinuxPort"), simpleDLL.class);
        
        // alte functii din dll
        //byte giveVoidPtrGetChar(Pointer param); // char giveVoidPtrGetChar(void* param);
        //int giveVoidPtrGetInt(Pointer param);   //int giveVoidPtrGetInt(void* param);
        //int giveIntGetInt(int a);               // int giveIntGetInt(int a);
        double hello();                      // void simpleCall();
        //void dtw(double[] r, double[] t, boolean pflag, Pointer Dist, Pointer D, Pointer k, Pointer w, Pointer rw, Pointer tw);
        double dtw(double[] r, int[] size_r, double[] t, int[] size_t, boolean pflag);
    }
	
	
	/*static {
	    try {
	    	System.load("libhello_world.so");
	    } catch (UnsatisfiedLinkError e) {
	      System.err.println("Native code library failed to load.\n" + e);
	      System.exit(1);
	    }
	  }*/

	
    public static void main(String[] args) {
 
    	System.out.println(System.getProperty("java.library.path"));
    	
        /*simpleDLL sdll = simpleDLL.INSTANCE; 
        double x = sdll.hello();  // function call        
        System.out.println("x = " + x);*/

        dtwDLL dtw = dtwDLL.INSTANCE;
        
        double[] r = {0.1, 0.2, 0.3, 0.4, 0.5};
        double[] t = {0.15, 0.3, 0.4, 0.5, 0.6};
        boolean pflag = false;
        int[] size_r = {1,5};
        int[] size_t = {1,5};
        double dist = dtw.dtw(r, size_r, t, size_t, pflag);
        System.out.println("dtw dist = " + dist);    
 
    }
    
}
