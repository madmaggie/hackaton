package studentmodel;

public class Personality {

	public final static int SANGUINIC = 0;
	public final static int COLERIC = 1;
	public final static int MELANCHOLIC = 2;
	public final static int PHLEGMATIC = 3;
	
}
