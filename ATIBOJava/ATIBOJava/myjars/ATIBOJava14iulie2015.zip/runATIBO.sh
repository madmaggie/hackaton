export LD_LIBRARY_PATH=.
java -jar ATIBOJava-27oct.jar
