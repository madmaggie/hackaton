clear
centersPerCategory=20;
%addpath('kMeans');
%addpath('RBFN');
varianta=1; %  1 for a test on recorded speech signal
            %  0 for recording a speech signal and test on it

if varianta
    [sound_file, pathname] = uigetfile('*.wav', 'Pick a sound file');
    cd (pathname)
    [Y,Fs,bits] = wavread(sound_file);
      
    %Y=detectVoce(Y,Fs);
    
else
    recObj = audiorecorder;
    disp('Start speaking.')
    recordblocking(recObj, 5);
    disp('End of Recording.');

    Fs=recObj.SampleRate;
    bits=recObj.BitsPerSample;

    Y = getaudiodata(recObj);
    %Y=detectVoce(Y,Fs);
end
    plot(Y), title('speech signal')

    load param_rbf_new_buna

[Y]    = soundnormalization(Y,Fs,Fs);
[Feat] = sound2features_plus(Y,Fs);
Feat=(Feat'-Minim)./(Maxim-Minim+eps);
scores = evaluateRBFN(Centers, betas, Theta, Feat);
[maxScore, category] = max(scores);
switch category
    case 1
        disp('Speech Emotion: Negative');
    case 2
        disp('Speech Emotion: Neutral');
    case 3
        disp('Speech Emotion: Pozitive');
end
